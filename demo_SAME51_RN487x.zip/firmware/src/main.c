/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include "../src/config/default/peripheral/rnHostLib/rnbd_example.h"

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

int main ( void )
{

    /* Initialize all modules */
    SYS_Initialize ( NULL );
    printf("BLE Data DEMO\r\n\r\n\r\n");
    printf("Connect RN487x on mBus Header 2 on Nano Base Board\r\n");
    printf("Open the Microchip Bluetooth Demo App on your phone\r\n");
    printf("Click on BLE Smart\r\n\r\n");
    printf("Search for RN487x and Click on it\r\n");
    printf("Press Connect and the state should change to Connected\r\n\r\n\r\n");
    printf("Expand Microchip Data Service\r\n");
    printf("Click on Microchip Data Characteristic (Write WriteNoResponse Notify Indicate)\r\n\r\n");
    printf("Under Read, Toggle ON Enable Notify/Indicate\r\n");
    printf("You should see 31 displayed (ASCII for 1)\r\n");
    
    RNBD_Example_Initialized();

    while ( true )
    {
    }

    /* Execution should not come here during normal operation */
    return ( EXIT_FAILURE );
}


/*******************************************************************************
 End of File
*/

